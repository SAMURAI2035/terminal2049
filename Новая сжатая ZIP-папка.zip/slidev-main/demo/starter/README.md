See [../../packages/create-app/template/README.md](../../packages/create-app/template/README.md)
