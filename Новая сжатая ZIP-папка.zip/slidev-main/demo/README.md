The best way of understanding Slidev is to try it, with the following command:

```bash
npm init slidev
```

Learn more: https://sli.dev
