<template>
  <Marker class="text-orange-400">
    Tips
  </Marker>
</template>
