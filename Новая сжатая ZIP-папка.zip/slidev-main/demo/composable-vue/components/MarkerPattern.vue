<template>
  <Marker class="text-pink-500">
    Pattern
  </Marker>
</template>
