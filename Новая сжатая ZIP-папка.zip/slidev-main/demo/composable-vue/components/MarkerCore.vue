<template>
  <Marker class="text-green-500">
    Core
  </Marker>
</template>
