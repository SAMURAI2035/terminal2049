# create-slidev

[![NPM version](https://img.shields.io/npm/v/create-slidev?color=3AB9D4&label=)](https://www.npmjs.com/package/create-slidev)

Starter template generater for [Slidev](https://sli.dev).

## Usage

```bash
npm init slidev
```

or

```bash
yarn create slidev
```

## License

MIT License © 2021 [Anthony Fu](https://github.com/antfu)

