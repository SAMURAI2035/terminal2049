# @slidev/types

[![NPM version](https://img.shields.io/npm/v/@slidev/types?color=3AB9D4&label=)](https://www.npmjs.com/package/@slidev/types)

Shared types for [Slidev](https://sli.dev).

## License

MIT License © 2021 [Anthony Fu](https://github.com/antfu)

