declare module '/@slidev/configs' {
  import { SlidevConfig } from './types'
  export default SlidevConfig
}
