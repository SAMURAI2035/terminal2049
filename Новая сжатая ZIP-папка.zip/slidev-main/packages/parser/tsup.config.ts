export { default } from '../../tsup.config'
