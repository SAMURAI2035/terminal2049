# @slidev/parser

[![NPM version](https://img.shields.io/npm/v/@slidev/parser?color=3AB9D4&label=)](https://www.npmjs.com/package/@slidev/parser)

Slides markdown parser for [Slidev](https://sli.dev).

Learn more about the [Syntax](https://sli.dev/guide/syntax.html)

Refer to the TypeScript definitions for API.

## License

MIT License © 2021 [Anthony Fu](https://github.com/antfu)

