<template>
  <div class="slidev-layout intro">
    <slot />
  </div>
</template>
