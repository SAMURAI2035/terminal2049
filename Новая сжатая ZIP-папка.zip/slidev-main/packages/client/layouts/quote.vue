<template>
  <div class="slidev-layout quote">
    <div class="my-auto">
      <slot />
    </div>
  </div>
</template>
