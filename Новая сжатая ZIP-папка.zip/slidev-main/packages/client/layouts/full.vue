<template>
  <div class="slidev-layout full w-full h-full">
    <slot class="w-full h-full" />
  </div>
</template>
