<template>
  <div class="slidev-layout statement">
    <div class="my-auto">
      <slot />
    </div>
  </div>
</template>
