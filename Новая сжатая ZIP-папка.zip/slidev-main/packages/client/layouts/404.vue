<template>
  <div class="px-4 py-10 text-center text-teal-700 dark:text-gray-200">
    404
  </div>
</template>
