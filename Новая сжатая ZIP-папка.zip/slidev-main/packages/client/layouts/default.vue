<template>
  <div class="slidev-layout default">
    <slot />
  </div>
</template>
