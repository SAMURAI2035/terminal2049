<template>
  <div class="slidev-layout fact">
    <div class="my-auto">
      <slot />
    </div>
  </div>
</template>
