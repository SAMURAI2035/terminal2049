<template>
  <div class="slidev-layout section">
    <slot />
  </div>
</template>
