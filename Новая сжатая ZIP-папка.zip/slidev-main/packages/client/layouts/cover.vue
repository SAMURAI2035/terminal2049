<template>
  <div class="slidev-layout cover">
    <slot />
  </div>
</template>
