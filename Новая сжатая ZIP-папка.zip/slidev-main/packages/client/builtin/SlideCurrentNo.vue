<template>
  <span>{{ $slidev.nav.currentPage }}</span>
</template>
