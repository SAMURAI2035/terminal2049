<template>
  <span>{{ $slidev.nav.total }}</span>
</template>
