<script setup lang="ts">
import setupRoot from './setup/root'

setupRoot()
</script>

<template>
  <RouterView />
  <StarportCarrier />
</template>
