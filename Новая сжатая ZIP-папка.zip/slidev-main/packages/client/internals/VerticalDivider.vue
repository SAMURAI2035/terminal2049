<template>
  <div class="w-1px opacity-10 bg-current m-1 lg:m-2" />
</template>
