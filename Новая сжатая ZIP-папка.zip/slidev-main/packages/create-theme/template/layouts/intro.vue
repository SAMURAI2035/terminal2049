<template>
  <div class="slidev-layout intro">
    <div class="my-auto">
      <slot />
    </div>
  </div>
</template>
