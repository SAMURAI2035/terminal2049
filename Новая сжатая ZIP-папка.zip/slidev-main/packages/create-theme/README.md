# create-slidev-theme

[![NPM version](https://img.shields.io/npm/v/create-slidev-theme?color=3AB9D4&label=)](https://www.npmjs.com/package/create-slidev-theme)

[Slidev](https://sli.dev) theme template generater.

## Usage

```bash
npm init slidev-theme
```

or

```bash
yarn create slidev-theme
```

## License

MIT License © 2021 [Anthony Fu](https://github.com/antfu)

