import { defineConfig } from 'vite'

export default defineConfig({
  build: {
    manifest: true,
    minify: false,
  },
})
