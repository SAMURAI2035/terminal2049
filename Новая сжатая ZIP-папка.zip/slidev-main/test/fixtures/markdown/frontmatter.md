---
layout: cover
fonts: 
  sans: Roboto, Lato
  serif: Mate SC
  mono: Fira Code
---
# Hi
---
meta:
  title: FooBar
  duration: 12
layout: center
---
# Hello
<!-- This is note -->
---

# Morning
---
layout: text
---
<!-- This is not note -->
Hey
<!-- This is note -->

---

```md
---
this should be treated as code block
---
----
```
