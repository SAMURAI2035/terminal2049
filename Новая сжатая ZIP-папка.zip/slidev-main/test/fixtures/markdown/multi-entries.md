---
src: sub/page1.md
---

---
src: /sub/page2.md
background: https://sli.dev/demo-cover.png#2
---

---
src: ./sub/pages3-4.md
background: https://sli.dev/demo-cover.png#34
---

---
src: sub/nested1-4.md
background: https://sli.dev/demo-cover.png#14
---

---

# Inline Page

$x+2$
