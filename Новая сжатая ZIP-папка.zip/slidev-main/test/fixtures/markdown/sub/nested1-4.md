---
src: /sub/page1.md
---

---
src: page2.md
---

---
src: ../sub/pages3-4.md
---
